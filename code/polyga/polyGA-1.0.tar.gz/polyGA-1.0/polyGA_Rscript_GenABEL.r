##
## This script defines the function 'r_get_pvals', which takes 
## a list of lists of SNPs and uses the GenABEL R package
## to test for SNP interactions. A list of p-values is returned.
##

libs_loaded = FALSE
library(GenABEL)

## Check that the required packages are loaded. If so, then load the genotype data.
libs_loaded = require(GenABEL)
if (libs_loaded == FALSE) {
	print("The required R packages failed to load!")
} else {
	## Load genotype gata in GenABEL format
	load('./data/sim_GenABEL.Rdata')

	## Export the data to each node in the cluster, if the cluster exists
	if (!is.null(cl)) {
		library(doSNOW)
		library(foreach)
		libs_loaded = require(doSNOW) & require(foreach)
		if (libs_loaded == FALSE) {
			print("The required R packages failed to load!")
		} else {
			registerDoSNOW(cl)
			clusterExport(cl, "gwas_data")
		}
	}
}

## Function for calculating p-values for each SNP pair
## The list of p-values is then accessed from polyGA
r_get_pvals = function(groups, clust) {
	num_groups = length(groups)
	if (!is.null(clust)) {
		p_values = foreach(i=1:num_groups, .combine="c", .multicombine=TRUE, .packages="GenABEL") %dopar% {
			test = scan.glm.2D("case~sex+CRSNP", family=binomial(), data=gwas_data, snps=groups[[i]], bcast=2)
			test$Pint2df[1,2]}
		clusterEvalQ(cl, gc())
	} else {
		p_values = c()
		for (i in 1:num_groups) {
                        test = scan.glm.2D("case~sex+CRSNP", family=binomial(), data=gwas_data, snps=groups[[i]], bcast=2)
                        p_values = c(p_values, test$Pint2df[1,2])
		}
	}
	gc()
	return(p_values)
}
