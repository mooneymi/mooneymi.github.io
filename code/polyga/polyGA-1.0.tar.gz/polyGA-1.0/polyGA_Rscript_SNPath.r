##
## This script defines the function 'r_get_pvals', which takes 
## a list of lists of SNPs and uses the GenABEL R package
## to test for SNP interactions. A list of p-values is returned.
##

libs_loaded = FALSE
library(SNPath)

## Check that the required packages are loaded. If so, then load the genotype data.
libs_loaded = require(SNPath)
if (libs_loaded == FALSE) {
	print("The required R packages failed to load!")
} else {
	## Loading data in SNPath format
	load('./data/sim_SNPath.Rdata')

	## loading the library on each node in the cluster, if the cluster exists
	if (!is.null(cl)) {
		clusterEvalQ(cl, library(SNPath))
	} 
}

## Function for calculating p-values for each SNP group
## The list of p-values is then passed back to polyGA
r_get_pvals = function(groups, clust) {
	p_values = aligator(cl=clust, snp.info=snp_info, gene.info=gene_info, gene.set=groups, snp.pval=pvals, gene.def='rel', snp.pcut=0.001)
	return(p_values)
}
